# -*- coding: utf-8 -*-
"""
spark_python_template example
=====================================
This example demonstrates how to use :mod:`spark_python_template`.
"""
